package test1;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Search {

	private static String START = "B";
	private static String END = "E";
	private List<String>allRoutes;

	public static void main(String[] args) {

		String fileName = null;
		Graph graph = null;
		BufferedReader br = null;
		Scanner kb = new Scanner(System.in);
		List<String> nodes = new ArrayList<String>();

		/* Get an file name from the user */
		System.out.print("Enter file name with network configuration: ");
		fileName = kb.nextLine();

		/* Open file */
		try {
			br = new BufferedReader(new FileReader(fileName));
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String line = null;
		String[] tokens = null;
		String first;
		String second;

		/* Create graph */
		graph = new Graph();


		try {
			while ((line = br.readLine()) != null) {
				tokens = line.split(" ");
				if (tokens.length != 2) {
					System.out.println("Invalid file format");
					br.close();
					graph = null;
					break;
				}
				first = tokens[0];
				second = tokens[1];

				if(!nodes.contains(first)) {
					System.out.println("Detected node: \"" + first + "\"");
					nodes.add(first);
				}

				if(!nodes.contains(second)) {
					System.out.println("Detected node: \"" + second + "\"");
					nodes.add(second);
				}


				System.out.println("Adding path between \"" + first + "\" , \"" + second + "\"");
				graph.addEdge(first, second);
			}

			System.out.println("Network paths created successfully");
			System.out.println("\n\nList of Nodes: ");

			for(String node : nodes) {
				System.out.println("\t" + node);
			}
		} catch(IOException e) {

		} finally{
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		kb = new Scanner(System.in);
		System.out.print("\nEnter Start Node: ");
		Search.START = kb.nextLine();

		kb = new Scanner(System.in);
		System.out.print("\nEnter End Node: ");
		Search.END = kb.nextLine();

		LinkedList<String> visited = new LinkedList();
		visited.add(START);
		Search sr = new Search();
		sr.depthFirst(graph, visited);

		/*for(String route : sr.getRoutes()) {
			System.out.println(route);
		}*/

		List<String> calcRoutes = sr.getRoutes();
		int totalRoutes = calcRoutes.size();
		System.out.println("\nTotal Number of routes between \"" + START + "\" and \"" + END + "\" is " + totalRoutes);

		int numRoutes = 0;
		
		do {
			kb = new Scanner(System.in);
			System.out.print("\nType \"exit\" to stop executing.\nNumber of randoem routes to be used for sending: ");
			String input = kb.nextLine();
			
			if("exit".equalsIgnoreCase(input)) {
				System.exit(0);
			}
			try {
				numRoutes = Integer.parseInt(input);
			} catch(NumberFormatException e) {
				System.out.println("Only numbers allowed");
				continue;
			}
			
			if(totalRoutes < numRoutes) {
				System.out.println("Error::\nInput routes greater than total routes\nInput = " + numRoutes + "\nTotal Routes = " + totalRoutes);
			} else {
				break;
			}
		} while(true);
		
		List<Integer> randomRouteIndexes = new ArrayList<Integer>();
		
		Random rand = new Random();
		while(randomRouteIndexes.size() < numRoutes) {
			int value = rand.nextInt(totalRoutes);
			randomRouteIndexes.add(value);
		}
		
		System.out.println("Random routes calculated are: \n");
		for(int index : randomRouteIndexes) {
			System.out.println(calcRoutes.get(index));
		}
	}

	public Search() {
		this.allRoutes = new ArrayList<String>();
	}

	private void depthFirst(Graph graph, LinkedList<String> visited) {
		LinkedList<String> nodes = graph.adjacentNodes(visited.getLast());
		// examine adjacent nodes
		for (String node : nodes) {
			if (visited.contains(node)) {
				continue;
			}
			if (node.equals(END)) {
				visited.add(node);
				addToRoutes(visited);
				visited.removeLast();
				break;
			}
		}
		for (String node : nodes) {
			if (visited.contains(node) || node.equals(END)) {
				continue;
			}
			visited.addLast(node);
			depthFirst(graph, visited);
			visited.removeLast();
		}
	}

	private void addToRoutes(LinkedList<String> visited) {
		StringBuilder routes = new StringBuilder();
		int length = visited.size();

		for (int count = 0; count < length; count++) {
			String node = visited.get(count);
			routes.append(node);
			if(count != length - 1) {
				routes.append("->");
			}
		}

		allRoutes.add(routes.toString());
	}

	private List<String> getRoutes() {
		return this.allRoutes;
	}
}
